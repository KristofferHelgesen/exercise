import React from "react";

export const SearchResults = ({
  getValue,
  searchTerm,
  selectedAdress,
  handleSearchItemClick,
}) => {
  return (
    <div className="searchResult">
      {getValue.length === 0 && searchTerm.length >= 3 ? (
        <p>No results for: {searchTerm} </p>
      ) : (
        <ul className="resultList">
          {getValue.map((item, i) => {
            return (
              <li
                className={selectedAdress === item ? "selected" : null}
                onClick={() => handleSearchItemClick(item)}
                key={i}
              >
                {`
                        ${item.street} - 
                        ${item.postNumber}  - 
                        ${item.city} 
                        `}
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
};

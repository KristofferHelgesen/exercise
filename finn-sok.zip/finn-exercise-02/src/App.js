import * as React from "react";
import TextField from "@mui/material/TextField";
import axios from "axios";
import { SearchResults } from "./components/SearchResults";

export function App() {
  const [searchTerm, setSearchTerm] = React.useState("");
  const [getValue, setGetValue] = React.useState([]);
  const [selectedAdress, setSelectedAdress] = React.useState();

  React.useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchTerm.length >= 3) {
        getAdress(searchTerm);
      } else {
        setGetValue([]);
      }
    }, 400);
    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  function getAdress(queryTerm) {
    queryTerm.length >= 3
      ? axios({
          method: "get",
          url: `http://localhost:8010/proxy/search/${queryTerm}`, // should be handeled in a data sevice with env config.
          headers: {
            "Content-Type": "application/json",
          },
        })
          .then((response) => {
            setGetValue(response.data.map((address) => sanatizeData(address)));
          })
          .catch((error) => {
            console.error("ERROR ", error);
          })
      : null;
  }

  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
    setSelectedAdress(null);
  };
  const handleSearchItemClick = (item) => {
    setSelectedAdress(item);
  };

  const sanatizeData = (object) => {
    const postNumber = object.postNumber.toString();
    const city = object.city;
    return {
      ...object,
      postNumber:
        postNumber.length === 3 ? "0" + postNumber : object.postNumber,
      city: city.charAt(0).toUpperCase() + city.slice(1).toLowerCase(),
    };
  };

  return (
    <main>
      <h1>Finn Andresse</h1>
      <div className="searchComponent">
        <div className="searchInputContainer">
          <TextField
            className="textField"
            label="Søk"
            variant="filled"
            onChange={handleInputChange}
          />
          <SearchResults
            getValue={getValue}
            searchTerm={searchTerm}
            selectedAdress={selectedAdress}
            handleSearchItemClick={handleSearchItemClick}
          />
        </div>
        {selectedAdress ? (
          <address>
            Gate: {selectedAdress.street} <br />
            By: {selectedAdress.city} <br />
            Kommune: {selectedAdress.county} <br />
            Fylke: {selectedAdress.municipality} <br />
          </address>
        ) : null}
      </div>
    </main>
  );
}

const path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

module.exports = () => {
  return {
    output: {
      path: path.join(__dirname, "/static/assets"),
      filename: "script.js",
    },
    devServer: {
      port: 3000,
      static: false,
    },
    module: {
      rules: [
        {
          test: /\.(js|jsx)$/,
          exclude: [/node_modules/],
          use: {
            loader: "babel-loader",
          },
        },
        {
          test: /\.scss$/,
          use: [MiniCssExtractPlugin.loader, "css-loader", "sass-loader"],
        },
      ],
    },
    plugins: [new MiniCssExtractPlugin({ filename: "styles.css" })],
  };
};
